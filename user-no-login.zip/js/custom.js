
jQuery.fn.initMenu = function() {  
    return this.each(function(){
        var theMenu = $(this).get(0);
        $('.collapsible .acitem', this).hide();
        // $('li.expand > .acitem', this).show();
        // $('li.expand > .acitem', this).prev().addClass('active');
        $('li span', this).click(
            function(e) {
                e.stopImmediatePropagation();
                var theElement = $(this).next();
                var parent = this.parentNode.parentNode;
                if($(parent).hasClass('noaccordion')) {
                    if(theElement[0] === undefined) {
                        window.location.href = this.href;
                    }
                    $(theElement).slideToggle('normal', function() {
                        if ($(this).is(':visible')) {
                            $(this).prev().addClass('active');
                        }
                        else {
                            $(this).prev().removeClass('active');
                        }    
                    });
                    return false;
                }
                else {
                    if(theElement.hasClass('acitem') && theElement.is(':visible')) {
                        if($(parent).hasClass('collapsible')) {
                            $('.acitem:visible', parent).first().slideUp('normal', 
                            function() {
                                $(this).prev().removeClass('active');
                            }
                        );
                        return false;  
                    }
                    return false;
                }
                if(theElement.hasClass('acitem') && !theElement.is(':visible')) {         
                    $('.acitem:visible', parent).first().slideUp('normal', function() {
                        $(this).prev().removeClass('active');
                    });
                    theElement.slideDown('normal', function() {
                        $(this).prev().addClass('active');
                    });
                    return false;
                }
            }
        }
    );
});
};

$(document).ready(function () {

    $('.menu').initMenu();


    $('#hamburger').click(function (e) {
        $('.dropDownMenu').fadeToggle();
        $(this).toggleClass('active');
        $('.dropDownMenu').find('ul.menu').toggleClass('collapsible');
    });

    $(document).mouseup(function (e){ // событие клика по веб-документу
		var div = $("#Topmenu"); // тут указываем ID элемента
		if (!div.is(e.target) // если клик был не по нашему блоку
        && div.has(e.target).length === 0 
        && $('#hamburger').hasClass('active')) 
        { // и не по его дочерним элементам
			//div.hide(); // скрываем его
      $('.dropDownMenu').fadeOut();
      $('#hamburger').removeClass("active");
		}	
	});





    $('.bpopup').click(function(e) {
        e.preventDefault();
        var href = $(this).attr('href');
        $(href).bPopup({
            follow: [ true , false ], // x, y 
                closeClass:'close'
            });
    });

    $(function(){

        $("#Tabs .Tab__head .Tab__tab").on("click", function(){
            var tabs = $("#Tabs .Tab__head .Tab__tab")
                cont = $("#Tabs .Tab__body .Tab__cont");
          // Удаляем классы active
            tabs.removeClass("active");
            cont.removeClass("active");
          // Добавляем классы active
            $(this).addClass("active");
            cont.eq($(this).index()).addClass("active");
            return false;
        });
    });

    $('.Forgot__password').click(function(e) {
        e.preventDefault();
        var href = $(this).attr('href');
        $('#Tab2').hide();
        $(href).show();
    });
    $('.Backlogin__link').click(function(e) {
        e.preventDefault();
        var href = $(this).attr('href');
        $('#Tab3').hide();
        $(href).show();
    });


    ///Select 
    $('.Select').each(function() {
        const _this = $(this),
            selectOption = _this.find('option'),
            selectOptionLength = selectOption.length,
            selectedOption = selectOption.filter(':selected'),
            duration = 450; // длительность анимации 
    
        _this.hide();
        _this.wrap('<div class="Select"></div>');
        $('<div>', {
            class: 'new-select',
            text: _this.children('option:disabled').text()
        }).insertAfter(_this);
    
        const selectHead = _this.next('.new-select');
        $('<div>', {
            class: 'new-select__list'
        }).insertAfter(selectHead);
    
        const selectList = selectHead.next('.new-select__list');
        for (let i = 1; i < selectOptionLength; i++) {
            $('<div>', {
                class: 'new-select__item',
                html: $('<span>', {
                    text: selectOption.eq(i).text()
                })
            })
            .attr('data-value', selectOption.eq(i).val())
            .appendTo(selectList);
        }
    
        const selectItem = selectList.find('.new-select__item');
        selectList.slideUp(0);
        selectHead.on('click', function() {
            if ( !$(this).hasClass('on') ) {
                $(this).addClass('on');
                selectList.slideDown(duration);
    
                selectItem.on('click', function() {
                    let chooseItem = $(this).data('value');
    
                    $('select').val(chooseItem).attr('selected', 'selected');
                    selectHead.text( $(this).find('span').text() );
    
                    selectList.slideUp(duration);
                    selectHead.removeClass('on');
                });
    
            } else {
                $(this).removeClass('on');
                selectList.slideUp(duration);
            }
        });
    });


    $(function($){
        // $("#field_2").mask("8(999)999-99-99");
        $('[name="phone"]').mask('+7 (999) 999-99-99');
       });


//$(document).ready(function () {
});
